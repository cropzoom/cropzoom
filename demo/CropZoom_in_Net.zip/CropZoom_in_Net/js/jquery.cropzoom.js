/*
CropZoom v1.0.4
Release Date: April 17, 2010

Copyright (c) 2010 Gaston Robledo

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
;(function($){

    var _self = null;
    var $options = null;
    var tMovement = null;

    $.fn.cropzoom = function(options){

        $options = $.extend(true,$.fn.cropzoom.defaults, options); 

        return this.each(function() {  

            //Verificamos que esten los plugins necesarios
            if(!$.isFunction($.fn.draggable) || !$.isFunction($.fn.resizable) || !$.isFunction($.fn.slider)){
                alert("You must include ui.draggable, ui.resizable and ui.slider to use cropZoom");
                return;
            }

            if($options.image.source == '' ||  $options.image.width == 0 || $options.image.height == 0){
                alert('You must set the source, witdth and height of the image element');
                return;
            }

            _self = $(this);
            _self.empty();
            _self.css({
                'width': $options.width,
                'height': $options.height,
                'background-color':$options.bgColor,
                'overflow':'hidden',
                'position':'relative',
                'border':'2px solid #333'
            });


            setData('image',{ 
                h: $options.image.height,
                w: $options.image.width,
                posY: 0,
                posX: 0,
                scaleX: 0,
                scaleY: 0,
                rotation: 0,
                source: $options.image.source,
                bounds:[0,0,0,0],
                id: 'image_to_crop_' + this.id
            });


            calculateFactor(getData('image'));
            getCorrectSizes(getData('image'));

            

            setData('selector',{
                x : $options.selector.x,
                y : $options.selector.y,
                w : ($options.selector.maxWidth != null ? ($options.selector.w > $options.selector.maxWidth ? $options.selector.maxWidth : $options.selector.w) : $options.selector.w),
                h : ($options.selector.maxHeight != null ? ($options.selector.h > $options.selector.maxHeight ? $options.selector.maxHeight : $options.selector.h) : $options.selector.h)
            });
            var $svg = null;
            var $image = null;
            if(!$.browser.msie){
                $svg = _self[0].ownerDocument.createElementNS('http://www.w3.org/2000/svg', 'svg');
                $svg.setAttribute('id', 'k');
                $svg.setAttribute('width', $options.width);
                $svg.setAttribute('height', $options.height);
                $svg.setAttribute('preserveAspectRatio', 'none');
                $image = _self[0].ownerDocument.createElementNS('http://www.w3.org/2000/svg','image');
                $image.setAttributeNS('http://www.w3.org/1999/xlink', 'href', $options.image.source);
                $image.setAttribute('width', getData('image').w);
                $image.setAttribute('height', getData('image').h);
                $image.setAttribute('id', getData('image').id);
                $image.setAttribute('preserveAspectRatio', 'none');
                $($image).attr('x', 0);
                $($image).attr('y', 0);
                $svg.appendChild($image);
            }else{
                // Add VML includes and namespace
                _self[0].ownerDocument.namespaces.add('v', 'urn:schemas-microsoft-com:vml', "#default#VML");
                // Add required css rules
                var style = document.createStyleSheet();
                style.addRule('v\\:image', "behavior: url(#default#VML);display:inline-block");
                style.addRule('v\\:image', "antiAlias: false;");

                $svg = $("<div />").attr("id","k").css({
                    'width':$options.width,
                    'height':$options.height,
                    'position':'absolute' 
                });
                $image = document.createElement('v:image');
                $image.setAttribute('id',getData('image').id);
                $image.setAttribute('src',$options.image.source);
                $image.setAttribute('gamma','0');

                $($image).css({
                    'position':'absolute',
                    'left': 0,
                    'top': 0,
                    'width': getData('image').w,
                    'height':getData('image').h
                });
                $image.setAttribute('coordsize', '21600,21600');
                $image.outerHTML = $image.outerHTML;


                var ext = getExtensionSource();
                if(ext == 'png' || ext == 'gif')
                    $image.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='"+$options.image.source+"',sizingMethod='scale');"; 
                $svg.append($image);   
            }
             $($image).data('container_id', this.id);
            _self.append($svg);  
            
            calculateTranslationAndRotation(getData('image'));         

            //Bindear el drageo a la imagen a cortar
            $($('#' + getData('image').id),$image).draggable({
                snap:true,
                drag:function(event,ui){ 
                    var $image = $(event.target);
                    var container_id = $image.data('container_id');
                    var $container = $('#' + container_id);
                    
                    $container.data('image').posY = ui.position.top;
                    $container.data('image').posX = ui.position.left;
                    if($options.image.snapToContainer)
                        limitBounds(ui,$container.data('image'));
                    else
                        calculateTranslationAndRotation($container.data('image'));
                    //Fire the callback
                    if($options.onImageDrag != null)
                        $options.onImageDrag($image,$container.data('image'));

                },
                stop:function(event,ui){
                    var $image = $(event.target);
                    var container_id = $image.data('container_id');
                    var $container = $('#' + container_id);
                    if($options.image.snapToContainer)
                        limitBounds(ui,$container.data('image'));
                }
            });


            //Creamos el selector  
            createSelector();
            //Cambiamos el resizable por un color solido
            _self.find('.ui-icon-gripsmall-diagonal-se').css({
                'background':'#FFF',
                'border':'1px solid #000',
                'width':8,
                'height':8
            });
            //Creamos la Capa de oscurecimiento
            createOverlay(this.id); 
            //Creamos el Control de Zoom 
            if($options.enableZoom) 
                createZoomSlider();
            //Creamos el Control de Rotacion
            if($options.enableRotation)
                createRotationSlider();
            if($options.expose.elementMovement != '')
                createMovementControls(); 
            //Maintein Chaining 
            return this;
        });

    };

    function limitBounds(ui,imageData){
        if (ui.position.top > 0)
            imageData.posY = 0;
        if (ui.position.left > 0)
            imageData.posX = 0;

        var bottom = -(imageData.h - ui.helper.parent().parent().height()),
        right  = -(imageData.w - ui.helper.parent().parent().width());
        if (ui.position.top < bottom)
            imageData.posY = bottom;
        if (ui.position.left < right)
            imageData.posX = right;
        calculateTranslationAndRotation(imageData);
    }

    function getExtensionSource(){
        var parts = $options.image.source.split('.');
        return parts[parts.length-1];    
    };

    function calculateFactor(imageData){  
        imageData.scaleX = ($options.width / imageData.w);
        imageData.scaleY = ($options.height / imageData.h); 
    };

    function getCorrectSizes(imageData){
        if($options.image.startZoom != 0){
            var zoomInPx_width =  (($options.image.width * Math.abs($options.image.startZoom)) / 100);
            var zoomInPx_height =  (($options.image.height * Math.abs($options.image.startZoom)) / 100);
            imageData.h = zoomInPx_height;
            imageData.w = zoomInPx_width;
            imageData.posY = 0;
            imageData.posX = 0;
        }else{
            imageData.posX = Math.abs(($options.width / 2) - (imageData.w / 2));
            imageData.posY = Math.abs(($options.height / 2) - (imageData.h/ 2));
            var scaleX = imageData.scaleX;
            var scaleY = imageData.scaleY;
            if(scaleY < scaleX){
                imageData.h = $options.height;
                imageData.w = Math.round(imageData.w * scaleY);
            }else{
                imageData.h = Math.round(imageData.h * scaleX); 
                imageData.w = $options.width;        
            }
        }
    };

    function calculateTranslationAndRotation(imageData){
        var rotacion = "";
        var traslacion = "";
        $(function(){
           // console.log(imageData.id);
            if($.browser.msie){
                rotacion = imageData.rotation;
                $('#' + imageData.id).css({
                    'rotation': rotacion,
                    'top': imageData.posY,
                    'left':imageData.posX
                });
            }else{
                rotacion = "rotate(" + imageData.rotation + "," + (imageData.posX + (imageData.w / 2 )) + "," + (imageData.posY + (imageData.h / 2))  + ")";    
                traslacion = " translate(" + imageData.posX + "," + imageData.posY + ")"; 
                rotacion += traslacion;
                $('#' + imageData.id).attr("transform",rotacion);
            }
        });
    };

    function createRotationSlider(){
        
        var rotationContainerSlider = $("<div />").attr('id','rotationContainer').mouseover(function(){
            $(this).css('opacity',1);
        }).mouseout(function(){
            $(this).css('opacity',0.6);
        });

        var rotMin = $('<div />').attr('id','rotationMin').html("0");
        var rotMax = $('<div />').attr('id','rotationMax').html("360");

        var $slider = $("<div />").attr('id','rotationSlider');
        //Aplicamos el Slider  
        var orientation = 'vertical';
        var value = 360;


        if($options.expose.slidersOrientation == 'horizontal' ){
            orientation = 'horizontal';
            value = 0;
        }
        $slider.data('container_id', _self[0].id);
        $slider.slider({
            orientation: orientation,  
            value: value,
            min: 0,
            max: 360,
            step: (($options.rotationSteps > 360 || $options.rotationSteps < 0) ? 1 : $options.rotationSteps),
            slide: function(event, ui) {
                 var container_id = $(this).data('container_id');
                var $container = $('#' + container_id);
                $container.data('image').rotation = (value == 360 ? Math.abs(360 - ui.value) : Math.abs(ui.value));
                calculateTranslationAndRotation($container.data('image')); 
                if($options.onRotate != null)
                    $options.onRotate($('#' + $container.data('image').id), $container.data('image').rotation);
            }
        });

        rotationContainerSlider.append(rotMin);
        rotationContainerSlider.append($slider);
        rotationContainerSlider.append(rotMax);

        if($options.expose.rotationElement != ''){
            $slider.addClass($options.expose.slidersOrientation);
            rotationContainerSlider.addClass($options.expose.slidersOrientation);
            rotMin.addClass($options.expose.slidersOrientation);
            rotMax.addClass($options.expose.slidersOrientation);
            $($options.expose.rotationElement).append(rotationContainerSlider);
        }else{
            $slider.addClass('vertical');
            rotationContainerSlider.addClass('vertical');
            rotMin.addClass('vertical');
            rotMax.addClass('vertical');
            rotationContainerSlider.css({
                'position':'absolute',
                'top': 5,
                'left': 5,
                'opacity':0.6
            });
            _self.append(rotationContainerSlider);
        }
    };

    function createZoomSlider(){

        var zoomContainerSlider = $("<div />").attr('id','zoomContainer').mouseover(function(){
            $(this).css('opacity',1);
        }).mouseout(function(){
            $(this).css('opacity',0.6);
        });

        var zoomMin = $('<div />').attr('id','zoomMin').html("<b>-</b>");
        var zoomMax = $('<div />').attr('id','zoomMax').html("<b>+</b>");

        var $slider = $("<div />").attr('id','zoomSlider');
        $slider.data('container_id', _self[0].id);
        //Aplicamos el Slider 
        $slider.slider({
            orientation: ($options.expose.zoomElement != '' ? $options.expose.slidersOrientation : 'vertical'),  
            value: ($options.image.startZoom != 0 ? $options.image.startZoom : getPercentOfZoom($('#'+ _self[0].id).data('image'))),
            min: ($options.image.useStartZoomAsMinZoom ? $options.image.startZoom : $options.image.minZoom),
            max: $options.image.maxZoom,
            step: (($options.zoomSteps > $options.image.maxZoom || $options.zoomSteps < 0) ? 1 : $options.zoomSteps),
            slide: function(event, ui) {
                var container_id = $(this).data('container_id');
                var $container = $('#' + container_id);
                var $image = $('#' + $container.data('image').id);
                 
                var zoomInPx_width =  (($options.image.width * Math.abs(ui.value)) / 100);
                var zoomInPx_height =  (($options.image.height * Math.abs(ui.value)) / 100);

                var viewPortCenterX =($options.width / 2);
                var viewPortCenterY =($options.height / 2);

                if(!$.browser.msie){
                    $image.attr('width',zoomInPx_width + "px");
                    $image.attr('height',zoomInPx_height + "px");
                }else{
                    $image.css({
                        'width': zoomInPx_width + "px",
                        'height': zoomInPx_height + "px"
                    });
                }


                var difX = ($container.data('image').w / 2) - (zoomInPx_width / 2);
                var difY = ($container.data('image').h / 2) - (zoomInPx_height / 2);

                var newX = (difX > 0 ? $container.data('image').posX + Math.abs(difX) : $container.data('image').posX - Math.abs(difX)); 
                var newY =  (difY > 0 ? $container.data('image').posY + Math.abs(difY) : $container.data('image').posY - Math.abs(difY));
                $container.data('image').posX = newX;
                $container.data('image').posY = newY;
                $container.data('image').w = zoomInPx_width;
                $container.data('image').h = zoomInPx_height;
                calculateFactor($container.data('image'));
                calculateTranslationAndRotation($container.data('image'));
                if($options.onZoom != null){
                    $options.onZoom($image,$container.data('image'));
                }
            }
        });

        if($options.slidersOrientation == 'vertical'){
            zoomContainerSlider.append(zoomMax);
            zoomContainerSlider.append($slider);
            zoomContainerSlider.append(zoomMin);
        }else{
            zoomContainerSlider.append(zoomMin);
            zoomContainerSlider.append($slider);
            zoomContainerSlider.append(zoomMax);
        }



        if($options.expose.zoomElement != ''){
            zoomMin.addClass($options.expose.slidersOrientation);
            zoomMax.addClass($options.expose.slidersOrientation);
            $slider.addClass($options.expose.slidersOrientation); 
            zoomContainerSlider.addClass($options.expose.slidersOrientation); 
            $($options.expose.zoomElement).append(zoomContainerSlider);
        }else{
            zoomMin.addClass('vertical');
            zoomMax.addClass('vertical');
            $slider.addClass('vertical'); 
            zoomContainerSlider.addClass('vertical'); 
            zoomContainerSlider.css({
                'position':'absolute',
                'top': 5,
                'right': 5,
                'opacity':0.6
            });
            _self.append(zoomContainerSlider);
        }
    };

    function getPercentOfZoom(imageData){
        var percent = 0;
        if(imageData.w > imageData.h){
            percent = ((imageData.w * 100) / $options.image.width);
        }else{
            percent = ((imageData.h * 100) / $options.image.height); 
        }
        return percent;
    };

    function createSelector(){
        if($options.selector.centered){
            getData('selector').y = ($options.height / 2) - (getData('selector').h / 2);  
            getData('selector').x = ($options.width / 2) - (getData('selector').w / 2);  
        }

        var _selector = $('<div />').attr('id',_self[0].id + '_selector').css({
            'width': getData('selector').w,
            'height': getData('selector').h,
            'top': getData('selector').y + 'px',
            'left': getData('selector').x + 'px',
            'border':'1px dashed ' + $options.selector.borderColor,
            'position':'absolute',
            'cursor':'move'
        }).mouseover(function(){
            $(this).css({
                'border':'1px dashed '+ $options.selector.borderColorHover
            })
        }).mouseout(function(){
            $(this).css({
                'border':'1px dashed '+ $options.selector.borderColor
            })
        });

         _selector.data('container_id', _self[0].id);
        //Aplicamos el drageo al selector
        _selector.draggable({
            containment: 'parent',
            iframeFix: true,
            refreshPositions: true,
            drag: function(event,ui){
                var $selector = $(event.target);
                var container_id = $selector.data('container_id');
                var $container = $('#' + container_id);
                //Actualizamos las posiciones de la mascara 
                $container.data('selector').x = ui.position.left;
                $container.data('selector').y = ui.position.top;
                makeOverlayPositions(ui, container_id, $selector);
                showInfo(_selector);
                if($options.onSelectorDrag != null)
                    $options.onSelectorDrag(_selector, $container.data('selector')); 
            },
            stop: function(event,ui){
                var $selector = $(event.target);
                var container_id = $selector.data('container_id');
                var $container = $('#' + container_id);
              
                //Ocultar la mascara
                hideOverlay(container_id);
                if($options.onSelectorDragStop != null)
                    $options.onSelectorDrag(_selector, $container.data('selector')); 
            } 
        });
        _selector.resizable({
            aspectRatio: $options.selector.aspectRatio,
            maxHeight: $options.selector.maxHeight, 
            maxWidth: $options.selector.maxWidth,
            minHeight : $options.selector.h,
            minWidth: $options.selector.w,
            containment: 'parent', 
            resize: function(event,ui){
                //Actualizamos las posiciones de la mascara
                getData('selector').w = _selector.width();
                getData('selector').h = _selector.height();
                makeOverlayPositions(ui);
                showInfo(_selector);
                if($options.onSelectorResize != null)
                    $options.onSelectorResize(_selector,getData('selector')); 
            },
            stop:function(event,ui){
                if($options.onSelectorResizeStop != null)
                    $options.onSelectorResizeStop(_selector,getData('selector'));
            }
        });     

        showInfo(_selector);
        //Agregamos el selector al objeto contenedor
        _self.append(_selector);
    };

    function showInfo(_selector){

        var _infoView = null;
        var alreadyAdded = false;
        if(_selector.find("#infoSelector").length > 0){
            _infoView = _selector.find("#infoSelector");
        }else{
            _infoView = $('<div />').attr('id','infoSelector').css({
                'position':'absolute',
                'top':0,
                'left':0,
                'background':$options.selector.bgInfoLayer,
                'opacity':0.6,
                'font-size':$options.selector.infoFontSize + 'px',
                'font-family':'Arial',
                'color':$options.selector.infoFontColor,
                'width':'100%'
            });
        }
        if($options.selector.showDimetionsOnDrag){
            _infoView.html("X:"+ getData('selector').x + "px - Y:" + getData('selector').y + "px");
            alreadyAdded = true;
        }
        if($options.selector.showPositionsOnDrag){
            if(alreadyAdded){
                _infoView.html(_infoView.html() + " | W:" + getData('selector').w + "px - H:" + getData('selector').h + "px");
            }else{
                _infoView.html("W:"+ getData('selector').w + "px - H:" + getData('selector').h + "px");
            }
        }
        _selector.append(_infoView);
    };

    function createOverlay(containerId){
       var arr =['t_' + containerId, 'b_' + containerId, 'l_' + containerId, 'r_' + containerId];
        $.each(arr,function(){
            var divO = $("<div />").attr("id",this).css({
             'overflow':'hidden',
             'background':$options.overlayColor,
             'opacity':0.6,
             'position':'absolute',
             'z-index':2,
             'visibility':'visible'   
            });
            _self.append(divO);  
        });
    };

    function makeOverlayPositions(ui, containerId, $selector){
       
            $("#t_" + containerId).css({
                "display":"block",
                "width":$options.width,
                'height': ui.position.top,
                'left': 0,
                'top':0
            });
            $("#b_" + containerId).css({
                "display":"block",
                "width":$options.width,
                'height': $options.height,
                'top': (ui.position.top + $selector.height()) + "px",
                'left': 0
            });
            $("#l_" + containerId).css({
                "display":"block",
                'left':0,
                'top': ui.position.top,
                'width': ui.position.left,
                'height': $selector.height()
            });
            $("#r_" + containerId).css({
                "display":"block",
                'top': ui.position.top,
                'left': (ui.position.left + $selector.width()) + "px",
                'width': $options.width,
                'height': $selector.height() + "px"
            });
    };

    function hideOverlay(containerId){
         $("#t_" + containerId).hide();
         $("#b_" + containerId).hide();
         $("#l_" + containerId).hide();
         $("#r_" + containerId).hide();
     }

    function setData(key,data){
        _self.data(key,data);
    };

    function getData(key){
        return _self.data(key);
    };

    function createMovementControls(){
        var table = $('<table>\
        <tr>\
        <td></td>\
        <td></td>\
        <td></td>\
        </tr>\
        <tr>\
        <td></td>\
        <td></td>\
        <td></td>\
        </tr>\
        <tr>\
        <td></td>\
        <td></td>\
        <td></td>\
        </tr>\
        </table>');
        var btns = [];
        btns.push($('<div />').addClass('mvn_no mvn'));
        btns.push($('<div />').addClass('mvn_n mvn'));
        btns.push($('<div />').addClass('mvn_ne mvn'));
        btns.push($('<div />').addClass('mvn_o mvn'));
        btns.push($('<div />').addClass('mvn_c'));
        btns.push($('<div />').addClass('mvn_e mvn'));
        btns.push($('<div />').addClass('mvn_so mvn'));
        btns.push($('<div />').addClass('mvn_s mvn'));
        btns.push($('<div />').addClass('mvn_se mvn'));
        for(var i=0;i<btns.length;i++){
            btns[i].mousedown(function(){
                $(this).data('container_id',_self[0].id);
                moveImage(this);             
            }).mouseup(function(){
                clearTimeout(tMovement);
            });
            table.find('td:eq('+i+')').append(btns[i]);
            $($options.expose.elementMovement).append(table);
            
        }   
    };

    function moveImage(obj){
        $container = $('#' + $(obj).data('container_id'));
        if($(obj).hasClass('mvn_no')){
            $container.data('image').posX = ($container.data('image').posX - $options.expose.movementSteps);
            $container.data('image').posY = ($container.data('image').posY - $options.expose.movementSteps);
        }else if($(obj).hasClass('mvn_n')){
            $container.data('image').posY = ($container.data('image').posY - $options.expose.movementSteps);
        }else if($(obj).hasClass('mvn_ne')){
            $container.data('image').posX = ($container.data('image').posX + $options.expose.movementSteps);
            $container.data('image').posY = ($container.data('image').posY - $options.expose.movementSteps);
        }else if($(obj).hasClass('mvn_o')){
            $container.data('image').posX = ($container.data('image').posX - $options.expose.movementSteps); 
        }else if($(obj).hasClass('mvn_c')){
            $container.data('image').posX = ($options.width/2)-($container.data('image').w/2);
            $container.data('image').posY = ($options.height/2)-($container.data('image').h/2);
        }else if($(obj).hasClass('mvn_e')){
            $container.data('image').posX = ($container.data('image').posX + $options.expose.movementSteps);
        }else if($(obj).hasClass('mvn_so')){
            $container.data('image').posX = ($container.data('image').posX - $options.expose.movementSteps);
            $container.data('image').posY = ($container.data('image').posY + $options.expose.movementSteps);
        }else if($(obj).hasClass('mvn_s')){
            getData('image').posY = ($container.data('image').posY + $options.expose.movementSteps);
        }else if($(obj).hasClass('mvn_se')){
            $container.data('image').posX = ($container.data('image').posX + $options.expose.movementSteps);
            $container.data('image').posY = ($container.data('image').posY + $options.expose.movementSteps);
        }   
        if($options.image.snapToContainer){
            if ($container.data('image').posY > 0) {
                $container.data('image').posY = 0;
            }
            if ($container.data('image').posX > 0) {
                $container.data('image').posX = 0;
            }


            var bottom = -($container.data('image').h - $container.height());
            var right  = -($container.data('image').w - $container.width());
            if ($container.data('image').posY < bottom) {
                $container.data('image').posY = bottom;
            }
            if ($container.data('image').posX < right) {
                $container.data('image').posX = right;
            }
        }
        calculateTranslationAndRotation($container.data('image'));
        tMovement = setTimeout(function(){
            moveImage(obj);
        },100);
    }                      

    /*Code taken from jquery.svgdom.js */
    /* Support adding class names to SVG nodes. */
    var origAddClass = $.fn.addClass;

    $.fn.addClass = function(classNames) {
        classNames = classNames || '';
        return this.each(function() {
            if (isSVGElem(this)) {
                var node = this;
                $.each(classNames.split(/\s+/), function(i, className) {
                    var classes = (node.className ? node.className.baseVal : node.getAttribute('class'));
                    if ($.inArray(className, classes.split(/\s+/)) == -1) {
                        classes += (classes ? ' ' : '') + className;
                        (node.className ? node.className.baseVal = classes :
                        node.setAttribute('class',  classes));
                    }
                });
            }
            else {
                origAddClass.apply($(this), [classNames]);
            }
        });
    };

    /* Support removing class names from SVG nodes. */
    var origRemoveClass = $.fn.removeClass;

    $.fn.removeClass = function(classNames) {
        classNames = classNames || '';
        return this.each(function() {
            if (isSVGElem(this)) {
                var node = this;
                $.each(classNames.split(/\s+/), function(i, className) {
                    var classes = (node.className ? node.className.baseVal : node.getAttribute('class'));
                    classes = $.grep(classes.split(/\s+/), function(n, i) { return n != className; }).
                    join(' ');
                    (node.className ? node.className.baseVal = classes :
                    node.setAttribute('class', classes));
                });
            }
            else {
                origRemoveClass.apply($(this), [classNames]);
            }
        });
    };

    /* Support toggling class names on SVG nodes. */
    var origToggleClass = $.fn.toggleClass;

    $.fn.toggleClass = function(className, state) {
        return this.each(function() {
            if (isSVGElem(this)) {
                if (typeof state !== 'boolean') {
                    state = !$(this).hasClass(className);
                }
                $(this)[(state ? 'add' : 'remove') + 'Class'](className);
            }
            else {
                origToggleClass.apply($(this), [className, state]);
            }
        });
    };

    /* Support checking class names on SVG nodes. */
    var origHasClass = $.fn.hasClass;

    $.fn.hasClass = function(className) {
        className = className || '';
        var found = false;
        this.each(function() {
            if (isSVGElem(this)) {
                var classes = (this.className ? this.className.baseVal :
                this.getAttribute('class')).split(/\s+/);
                found = ($.inArray(className, classes) > -1);
            }
            else {
                found = (origHasClass.apply($(this), [className]));
            }
            return !found;
        });
        return found;
    };

    /* Support attributes on SVG nodes. */
    var origAttr = $.fn.attr;

    $.fn.attr = function(name, value, type) {
        if (typeof name === 'string' && value === undefined) {
            var val = origAttr.apply(this, [name, value, type]);
            return (val && val.baseVal ? val.baseVal.valueAsString : val);
        }
        var options = name;
        if (typeof name === 'string') {
            options = {};
            options[name] = value;
        }
        return this.each(function() {
            if (isSVGElem(this)) {
                for (var n in options) {
                    this.setAttribute(n,
                    (typeof options[n] == 'function' ? options[n]() : options[n]));
                }
            }
            else {
                origAttr.apply($(this), [name, value, type]);
            }
        });
    };

    /* Support removing attributes on SVG nodes. */
    var origRemoveAttr = $.fn.removeAttr;

    $.fn.removeAttr = function(name) {
        return this.each(function() {
            if (isSVGElem(this)) {
                (this[name] && this[name].baseVal ? this[name].baseVal.value = '' :
                this.setAttribute(name, ''));
            }
            else {
                origRemoveAttr.apply($(this), [name]);
            }
        });
    }; 

    function isSVGElem(node) {
        return (node.nodeType == 1 && node.namespaceURI == 'http://www.w3.org/2000/svg');
    };

    function getParameters(custom){
        var image = getData('image');
        var selector = getData('selector');
        var fixed_data = {
            'viewPortW': _self.width(),
            'viewPortH': _self.height(),
            'imageX':image.posX,
            'imageY': image.posY,
            'imageRotate': image.rotation,
            'imageW': image.w,
            'imageH': image.h,
            'imageSource': image.source,
            'selectorX': selector.x,
            'selectorY': selector.y,
            'selectorW': selector.w,
            'selectorH': selector.h
        };
        return $.extend(fixed_data,custom);
    };

    /* Defaults */ 
    $.fn.cropzoom.defaults = {  
        width: 500,  
        height: 375,
        bgColor: '#000',
        overlayColor: '#000',    
        selector: {
            x:0,
            y:0,
            w:229,
            h:100,
            aspectRatio:false,
            centered:false,
            borderColor: 'yellow',
            borderColorHover: 'red',
            bgInfoLayer: '#FFF',
            infoFontSize: 10,
            infoFontColor: 'blue',
            showPositionsOnDrag: true,
            showDimetionsOnDrag: true,
            maxHeight:null,
            maxWidth:null
        },
        image: {source:'',rotation:0,width:0,height:0,minZoom:10,maxZoom:150,startZoom:50,useStartZoomAsMinZoom:false,snapToContainer:false},
        enableRotation: true,
        enableZoom: true,
        zoomSteps: 1,
        rotationSteps: 5, 
        expose: {
            slidersOrientation: 'vertical',
            zoomElement: '', 
            rotationElement: '',
            elementMovement: '', 
            movementSteps: 5
        },
        onSelectorDrag:null,
        onSelectorDragStop: null,
        onSelectorResize: null,
        onSelectorResizeStop: null,
        onZoom: null,
        onRotate:null,
        onImageDrag:null

    };

    $.fn.extend({
        //Function to set the selector position and sizes
        setSelector: function(x,y,w,h,animate){
            if(animate != undefined && animate == true){
                $('#selector').animate({
                    'top': y,
                    'left': x,
                    'width': w,
                    'height': h
                },'slow');
            }else{
                $('#selector').css({
                    'top': y,
                    'left': x,
                    'width': w,
                    'height': h
                });
            }
            setData('selector',{
                x: x,
                y: y,
                w: w,
                h: h
            });
        },
        //Restore the Plugin
        restore: function(){
            _self.empty();
            setData('image',{});
            setData('selector',{});
            if($options.expose.zoomElement != ""){
                $($options.expose.zoomElement).empty();
            }
            if($options.expose.rotationElement != ""){
                $($options.expose.rotationElement).empty();
            }
            if($options.expose.elementMovement != ""){
                $($options.expose.elementMovement).empty(); 
            }
            _self.cropzoom($options);


        },
        //Send the Data to the Server
        send : function(url,type,custom,onSuccess){

            var response = "";
            $.ajax({
                url : url,
                type: type,
                data: (getParameters(custom)),
                success:function(r){ 
                    setData('imageResult',r);
                    if(onSuccess !== undefined && onSuccess != null)
                        onSuccess(r);
                }
            });
        }  
    });

})(jQuery);
